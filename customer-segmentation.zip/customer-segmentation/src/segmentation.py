"""
segmentation.py
Customer Segmentation using K-Means Clustering
- Preprocessing & feature engineering
- Optimal k selection (Elbow + Silhouette)
- Cluster profiling
- Visualization suite
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
import seaborn as sns
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, silhouette_samples
import warnings
warnings.filterwarnings('ignore')

# ── Style ──────────────────────────────────────────────────────────────────────
PALETTE = ['#4C6EF5', '#F76707', '#2F9E44', '#E03131', '#7048E8']
SEGMENT_LABELS = {0: 'Budget Loyalists', 1: 'Premium Explorers',
                  2: 'Casual Browsers', 3: 'High-Value VIPs', 4: 'At-Risk Inactives'}
plt.rcParams.update({
    'figure.facecolor': 'white', 'axes.facecolor': '#F8F9FA',
    'axes.grid': True, 'grid.alpha': 0.4, 'grid.linestyle': '--',
    'font.family': 'DejaVu Sans', 'axes.spines.top': False, 'axes.spines.right': False,
})

# ── Load & Feature Engineering ─────────────────────────────────────────────────
df = pd.read_csv('/home/claude/customer-segmentation/data/customers.csv')

# RFM proxy features
df['spend_per_visit']   = df['annual_spend'] / df['purchase_frequency']
df['income_spend_ratio'] = df['annual_spend'] / df['annual_income']
df['engagement_score']  = (df['loyalty_score'] * 0.5 +
                            (1 - df['churn_risk']) * 50 * 0.3 +
                            df['months_active'] / 60 * 100 * 0.2)

FEATURES = [
    'age', 'annual_income', 'annual_spend', 'purchase_frequency',
    'avg_order_value', 'online_purchase_ratio', 'discount_sensitivity',
    'loyalty_score', 'churn_risk', 'months_active', 'category_diversity',
    'spend_per_visit', 'income_spend_ratio', 'engagement_score'
]

X = df[FEATURES].copy()
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ── PCA for Visualization ──────────────────────────────────────────────────────
pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X_scaled)
df['pca1'] = X_pca[:, 0]
df['pca2'] = X_pca[:, 1]

# ── Optimal k (Elbow + Silhouette) ────────────────────────────────────────────
k_range = range(2, 9)
inertias, sil_scores = [], []
for k in k_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_scaled)
    inertias.append(km.inertia_)
    sil_scores.append(silhouette_score(X_scaled, labels))

BEST_K = 5

# ── Final Model ───────────────────────────────────────────────────────────────
km_final = KMeans(n_clusters=BEST_K, random_state=42, n_init=20)
df['cluster'] = km_final.fit_predict(X_scaled)

# Map to descriptive labels (by avg spend order)
cluster_spend = df.groupby('cluster')['annual_spend'].mean().rank().astype(int) - 1
label_map = {c: list(SEGMENT_LABELS.values())[r] for c, r in cluster_spend.items()}
df['segment'] = df['cluster'].map(label_map)
color_map = {seg: PALETTE[i] for i, seg in enumerate(SEGMENT_LABELS.values())}

sil_final = silhouette_score(X_scaled, df['cluster'])
print(f"Silhouette Score (k={BEST_K}): {sil_final:.3f}")

# ── FIGURE 1: Model Selection ─────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('Optimal Cluster Selection', fontsize=16, fontweight='bold', y=1.02)

ax1 = axes[0]
ax1.plot(list(k_range), inertias, 'o-', color='#4C6EF5', linewidth=2.5, markersize=7)
ax1.axvline(BEST_K, color='#E03131', linestyle='--', alpha=0.7, label=f'Chosen k={BEST_K}')
ax1.set(title='Elbow Method (Inertia)', xlabel='Number of Clusters (k)', ylabel='Inertia')
ax1.legend()

ax2 = axes[1]
ax2.plot(list(k_range), sil_scores, 's-', color='#2F9E44', linewidth=2.5, markersize=7)
ax2.axvline(BEST_K, color='#E03131', linestyle='--', alpha=0.7, label=f'Chosen k={BEST_K}')
ax2.set(title='Silhouette Score', xlabel='Number of Clusters (k)', ylabel='Silhouette Score')
ax2.legend()

plt.tight_layout()
plt.savefig('/home/claude/customer-segmentation/outputs/01_model_selection.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: 01_model_selection.png")

# ── FIGURE 2: PCA Scatter ─────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(10, 7))
for seg in df['segment'].unique():
    mask = df['segment'] == seg
    ax.scatter(df.loc[mask, 'pca1'], df.loc[mask, 'pca2'],
               c=color_map[seg], label=seg, alpha=0.65, s=40, edgecolors='white', linewidth=0.4)

ax.set(title=f'Customer Segments — PCA Projection\n(Variance explained: {pca.explained_variance_ratio_.sum():.1%})',
       xlabel=f'PC1 ({pca.explained_variance_ratio_[0]:.1%} variance)',
       ylabel=f'PC2 ({pca.explained_variance_ratio_[1]:.1%} variance)')
ax.legend(title='Segment', loc='upper right', framealpha=0.9)
plt.tight_layout()
plt.savefig('/home/claude/customer-segmentation/outputs/02_pca_clusters.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: 02_pca_clusters.png")

# ── FIGURE 3: Segment Profiles (Radar / Bar) ─────────────────────────────────
profile_features = ['annual_income', 'annual_spend', 'purchase_frequency',
                    'loyalty_score', 'churn_risk', 'category_diversity', 'online_purchase_ratio']
profile = df.groupby('segment')[profile_features].mean()

# Normalize 0-1
profile_norm = (profile - profile.min()) / (profile.max() - profile.min())

fig, axes = plt.subplots(2, 4, figsize=(18, 8))
fig.suptitle('Segment Profile: Normalized Feature Means', fontsize=16, fontweight='bold')
axes = axes.flatten()
for i, feat in enumerate(profile_features):
    ax = axes[i]
    segs = profile_norm.index.tolist()
    vals = profile_norm[feat].values
    bars = ax.bar(segs, vals, color=[color_map.get(s, '#ccc') for s in segs], edgecolor='white', width=0.6)
    ax.set_title(feat.replace('_', ' ').title(), fontsize=10, fontweight='bold')
    ax.set_ylim(0, 1.15)
    ax.set_xticklabels(segs, rotation=30, ha='right', fontsize=7)
    for bar, val in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.03,
                f'{val:.2f}', ha='center', va='bottom', fontsize=7)
axes[-1].set_visible(False)
plt.tight_layout()
plt.savefig('/home/claude/customer-segmentation/outputs/03_segment_profiles.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: 03_segment_profiles.png")

# ── FIGURE 4: Distribution Dashboard ─────────────────────────────────────────
fig = plt.figure(figsize=(18, 12))
gs = GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35)
fig.suptitle('Customer Segment Distribution Dashboard', fontsize=16, fontweight='bold')

# Segment sizes
ax0 = fig.add_subplot(gs[0, 0])
seg_counts = df['segment'].value_counts()
wedges, texts, autotexts = ax0.pie(
    seg_counts.values, labels=seg_counts.index,
    colors=[color_map[s] for s in seg_counts.index],
    autopct='%1.1f%%', startangle=140, textprops={'fontsize': 7})
ax0.set_title('Segment Distribution', fontweight='bold')

# Age distribution by segment
ax1 = fig.add_subplot(gs[0, 1:])
for seg in df['segment'].unique():
    data = df[df['segment'] == seg]['age']
    ax1.hist(data, bins=15, alpha=0.5, label=seg, color=color_map[seg], edgecolor='white')
ax1.set(title='Age Distribution by Segment', xlabel='Age', ylabel='Count')
ax1.legend(fontsize=7, loc='upper right')

# Income vs Spend
ax2 = fig.add_subplot(gs[1, :2])
for seg in df['segment'].unique():
    mask = df['segment'] == seg
    ax2.scatter(df.loc[mask,'annual_income']/1000, df.loc[mask,'annual_spend']/1000,
                c=color_map[seg], label=seg, alpha=0.5, s=20)
ax2.set(title='Income vs Annual Spend', xlabel='Annual Income ($k)', ylabel='Annual Spend ($k)')
ax2.legend(fontsize=7)

# Churn Risk by segment
ax3 = fig.add_subplot(gs[1, 2])
churn_data = [df[df['segment'] == s]['churn_risk'].values for s in SEGMENT_LABELS.values() if s in df['segment'].unique()]
seg_names = [s for s in SEGMENT_LABELS.values() if s in df['segment'].unique()]
bp = ax3.boxplot(churn_data, patch_artist=True, medianprops={'color': 'black', 'linewidth': 2})
for patch, seg in zip(bp['boxes'], seg_names):
    patch.set_facecolor(color_map[seg])
    patch.set_alpha(0.7)
ax3.set(title='Churn Risk Distribution', ylabel='Churn Risk', xticklabels=[s.split()[0] for s in seg_names])
ax3.tick_params(axis='x', rotation=30)

# Purchase frequency
ax4 = fig.add_subplot(gs[2, 0])
seg_freq = df.groupby('segment')['purchase_frequency'].mean().sort_values()
ax4.barh(seg_freq.index, seg_freq.values, color=[color_map[s] for s in seg_freq.index])
ax4.set(title='Avg Purchase Frequency', xlabel='Times/Year')
ax4.tick_params(axis='y', labelsize=7)

# Loyalty score
ax5 = fig.add_subplot(gs[2, 1])
seg_loy = df.groupby('segment')['loyalty_score'].mean().sort_values()
ax5.barh(seg_loy.index, seg_loy.values, color=[color_map[s] for s in seg_loy.index])
ax5.set(title='Avg Loyalty Score', xlabel='Score (0-100)')
ax5.tick_params(axis='y', labelsize=7)

# Favorite category heatmap
ax6 = fig.add_subplot(gs[2, 2])
cat_seg = pd.crosstab(df['favorite_category'], df['segment'], normalize='columns').round(2)
sns.heatmap(cat_seg, ax=ax6, cmap='Blues', annot=True, fmt='.2f',
            annot_kws={'size': 6}, linewidths=0.5, cbar=False)
ax6.set(title='Category Preference\n(by segment)', xlabel='')
ax6.tick_params(axis='x', rotation=30, labelsize=6)
ax6.tick_params(axis='y', labelsize=7)

plt.savefig('/home/claude/customer-segmentation/outputs/04_dashboard.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: 04_dashboard.png")

# ── FIGURE 5: Silhouette Plot ─────────────────────────────────────────────────
sil_vals = silhouette_samples(X_scaled, df['cluster'])
fig, ax = plt.subplots(figsize=(10, 6))
y_lower = 10
for i in range(BEST_K):
    ith_sil = np.sort(sil_vals[df['cluster'] == i])
    size = ith_sil.shape[0]
    y_upper = y_lower + size
    seg = label_map[i]
    ax.fill_betweenx(np.arange(y_lower, y_upper), 0, ith_sil, alpha=0.7, color=color_map[seg])
    ax.text(-0.05, y_lower + 0.5 * size, seg.split()[0], ha='right', fontsize=8)
    y_lower = y_upper + 10

ax.axvline(sil_final, color='red', linestyle='--', label=f'Avg = {sil_final:.3f}')
ax.set(title='Silhouette Analysis per Segment', xlabel='Silhouette Coefficient', ylabel='Cluster')
ax.legend()
plt.tight_layout()
plt.savefig('/home/claude/customer-segmentation/outputs/05_silhouette.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: 05_silhouette.png")

# ── Segment Summary Table ──────────────────────────────────────────────────────
summary = df.groupby('segment').agg(
    Count=('customer_id', 'count'),
    Avg_Age=('age', 'mean'),
    Avg_Income=('annual_income', 'mean'),
    Avg_Spend=('annual_spend', 'mean'),
    Avg_Frequency=('purchase_frequency', 'mean'),
    Avg_Loyalty=('loyalty_score', 'mean'),
    Avg_ChurnRisk=('churn_risk', 'mean'),
    Online_Ratio=('online_purchase_ratio', 'mean'),
).round(2)
summary.to_csv('/home/claude/customer-segmentation/outputs/segment_summary.csv')
print("\n── Segment Summary ──────────────────────────────────────")
print(summary.to_string())

df.to_csv('/home/claude/customer-segmentation/outputs/customers_segmented.csv', index=False)
print("\n✅ All outputs saved to /home/claude/customer-segmentation/outputs/")
