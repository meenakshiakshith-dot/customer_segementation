"""
generate_data.py
Generates a realistic synthetic customer dataset for segmentation analysis.
"""

import numpy as np
import pandas as pd

np.random.seed(42)
N = 500

# --- Demographics ---
ages = np.concatenate([
    np.random.normal(25, 3, 100),   # young adults
    np.random.normal(35, 5, 150),   # mid-career
    np.random.normal(50, 7, 150),   # established
    np.random.normal(65, 5, 100),   # seniors
]).clip(18, 80).astype(int)

genders = np.random.choice(['Male', 'Female', 'Other'], N, p=[0.47, 0.47, 0.06])

incomes = np.concatenate([
    np.random.normal(28000, 5000, 100),
    np.random.normal(55000, 8000, 150),
    np.random.normal(85000, 12000, 150),
    np.random.normal(45000, 10000, 100),
]).clip(15000, 200000).astype(int)

education = np.random.choice(
    ['High School', 'Some College', "Bachelor's", "Master's", 'PhD'],
    N, p=[0.20, 0.20, 0.35, 0.18, 0.07]
)

regions = np.random.choice(
    ['North', 'South', 'East', 'West', 'Central'],
    N, p=[0.20, 0.25, 0.20, 0.20, 0.15]
)

# --- Purchase Behavior ---
annual_spend = (incomes * np.random.uniform(0.03, 0.18, N)).astype(int)
purchase_freq = np.random.poisson(lam=ages / 10, size=N).clip(1, 52)
avg_order_value = (annual_spend / purchase_freq).astype(int)
online_ratio = np.random.beta(2, 2, N).round(2)
discount_sensitivity = np.random.beta(3, 2, N).round(2)
loyalty_score = np.random.randint(0, 101, N)
churn_risk = (1 - loyalty_score / 100 + np.random.normal(0, 0.1, N)).clip(0, 1).round(2)
months_active = np.random.randint(1, 61, N)

# --- Product Preferences ---
categories = ['Electronics', 'Fashion', 'Home & Garden', 'Sports', 'Beauty', 'Books & Media', 'Food & Grocery']
fav_category = np.random.choice(categories, N)
category_diversity = np.random.randint(1, len(categories) + 1, N)

df = pd.DataFrame({
    'customer_id': [f'C{str(i).zfill(4)}' for i in range(1, N + 1)],
    'age': ages,
    'gender': genders,
    'annual_income': incomes,
    'education': education,
    'region': regions,
    'annual_spend': annual_spend,
    'purchase_frequency': purchase_freq,
    'avg_order_value': avg_order_value,
    'online_purchase_ratio': online_ratio,
    'discount_sensitivity': discount_sensitivity,
    'loyalty_score': loyalty_score,
    'churn_risk': churn_risk,
    'months_active': months_active,
    'favorite_category': fav_category,
    'category_diversity': category_diversity,
})

df.to_csv('/home/claude/customer-segmentation/data/customers.csv', index=False)
print(f"Dataset generated: {len(df)} customers, {len(df.columns)} features")
print(df.describe().round(2))
