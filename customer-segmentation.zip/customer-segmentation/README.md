# 🛍️ Customer Segmentation Analysis

> Behavioral and demographic clustering of retail customers using K-Means and PCA — built as part of an internship data analytics project.

---

## 📌 Project Overview

This project segments 500 retail customers into **5 distinct behavior-demographic profiles** using unsupervised machine learning. It covers the full analytics pipeline — from synthetic data generation to visual dashboards — using Python (scikit-learn, pandas, matplotlib, seaborn).

---

## 🎯 Objectives

- Identify meaningful customer groups based on **purchase behavior** and **demographics**
- Apply **K-Means clustering** with principled cluster selection (Elbow + Silhouette)
- Visualize segments through **PCA projection**, **profile dashboards**, and **distribution charts**
- Generate actionable **marketing insights** per segment

---

## 📁 Project Structure

```
customer-segmentation/
│
├── data/
│   └── customers.csv              # Synthetic dataset (500 customers, 16 features)
│
├── src/
│   ├── generate_data.py           # Synthetic data generation
│   └── segmentation.py            # Clustering, analysis & all visualizations
│
├── outputs/
│   ├── 01_model_selection.png     # Elbow + Silhouette plots
│   ├── 02_pca_clusters.png        # PCA 2D scatter by segment
│   ├── 03_segment_profiles.png    # Normalized feature profiles per segment
│   ├── 04_dashboard.png           # Full distribution dashboard
│   ├── 05_silhouette.png          # Per-cluster silhouette analysis
│   ├── segment_summary.csv        # Aggregated stats per segment
│   └── customers_segmented.csv    # Full dataset with cluster labels
│
├── notebook/
│   └── Customer_Segmentation.ipynb  # Jupyter walkthrough (optional)
│
├── requirements.txt
└── README.md
```

---

## 🔢 Dataset Features

| Category | Features |
|---|---|
| **Demographics** | Age, Gender, Annual Income, Education, Region |
| **Purchase Behavior** | Annual Spend, Purchase Frequency, Avg Order Value |
| **Engagement** | Loyalty Score, Churn Risk, Months Active, Online Ratio |
| **Preferences** | Favorite Category, Category Diversity, Discount Sensitivity |
| **Engineered** | Spend per Visit, Income-Spend Ratio, Engagement Score |

---

## 🧠 Methodology

### 1. Feature Engineering
Three composite features were derived:
- `spend_per_visit` = annual_spend / purchase_frequency
- `income_spend_ratio` = annual_spend / annual_income
- `engagement_score` = weighted composite of loyalty, churn risk, and tenure

### 2. Preprocessing
- StandardScaler normalization across all 14 numerical features

### 3. Optimal Cluster Selection
| Method | Finding |
|---|---|
| Elbow (Inertia) | Clear bend at k = 4–5 |
| Silhouette Score | Peak at k = 5 |
| **Chosen k** | **5** |

### 4. Dimensionality Reduction
- PCA (2 components) for visualization only — clustering runs on full 14-D space

---

## 👥 Customer Segments

| Segment | Count | Avg Income | Avg Spend | Loyalty | Churn Risk | Key Trait |
|---|---|---|---|---|---|---|
| **Budget Loyalists** | 119 | $41K | $4.2K | 70 | 0.29 | Young, faithful, low spend |
| **Premium Explorers** | 100 | $54K | $4.3K | 73 | 0.26 | Older, very loyal, frequent buyers |
| **Casual Browsers** | 146 | $55K | $4.5K | 19 | 0.82 | Mid-age, **high churn risk** |
| **High-Value VIPs** | 43 | $65K | $9.0K | 53 | 0.43 | High spend, low frequency |
| **At-Risk Inactives** | 92 | $81K | $11K | 48 | 0.53 | High earners, high churn |

---

## 💡 Marketing Recommendations

| Segment | Strategy |
|---|---|
| **Budget Loyalists** | Loyalty rewards, bundle deals, referral programs |
| **Premium Explorers** | Senior-friendly UX, curated subscriptions, early access |
| **Casual Browsers** | Re-engagement emails, personalized recommendations, time-limited offers |
| **High-Value VIPs** | Concierge service, exclusive launches, premium memberships |
| **At-Risk Inactives** | Win-back campaigns, high-value promotions, account managers |

---

## 📊 Visualizations

| Chart | Description |
|---|---|
| `01_model_selection.png` | Elbow + Silhouette score curves to justify k=5 |
| `02_pca_clusters.png` | 2D PCA scatter plot colored by segment |
| `03_segment_profiles.png` | Normalized bar charts comparing feature means |
| `04_dashboard.png` | Full 6-panel analytics dashboard |
| `05_silhouette.png` | Per-sample silhouette coefficients by cluster |

---

## 🚀 How to Run

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/customer-segmentation.git
cd customer-segmentation

# 2. Install dependencies
pip install -r requirements.txt

# 3. Generate dataset
python src/generate_data.py

# 4. Run full segmentation + visualization
python src/segmentation.py
```

All outputs will be saved to the `outputs/` folder.

---

## 📦 Requirements

```
pandas>=1.5
numpy>=1.23
scikit-learn>=1.2
matplotlib>=3.6
seaborn>=0.12
```

---

## 🛠️ Tech Stack

- **Language:** Python 3.10+
- **ML:** scikit-learn (KMeans, PCA, StandardScaler)
- **Data:** pandas, numpy
- **Visualization:** matplotlib, seaborn

---

## 📝 Internship Context

This project was completed as part of a **Data Analytics Internship**, demonstrating skills in:
- Unsupervised machine learning
- Customer analytics & RFM-style analysis
- Data storytelling and business insight generation
- End-to-end Python data science workflow

---

## 👤 Author

**[Your Name]**  
Data Analytics Intern  
[Your LinkedIn] · [Your Email]
